package main

import (
	"flag"
	"fmt"
	"io"
	"net"
	"os"
)

type Client struct {
	ServerIp   string
	ServerPort int
	Name       string
	conn       net.Conn
	flag       int
}

func NewClient(serverIp string, serverPort int) *Client {
	client := &Client{
		ServerIp:   serverIp,
		ServerPort: serverPort,
		flag:       9999,
	}
	conn, error := net.Dial("tcp", fmt.Sprintf("%s:%d", serverIp, serverPort))
	if error != nil {
		fmt.Println("net dial error...")
		return nil
	}
	client.conn = conn
	return client
}

func (c *Client) menu() bool {
	var flag int

	fmt.Println("1.公聊模式")
	fmt.Println("2.私聊模式")
	fmt.Println("3.修改用户名")
	fmt.Println("0.退出")

	fmt.Scanln(&flag)
	if flag >= 0 && flag <= 3 {
		c.flag = flag
		return true
	} else {
		fmt.Println(">>>>请输入合法数字<<<<")
		return false
	}
}

//修改用户名
func (c *Client) UpdateName() bool {
	fmt.Println(">>>>请输入用户名")
	fmt.Scanln(&c.Name)

	sendMsg := "rename|" + c.Name + "\n"
	_, error := c.conn.Write([]byte(sendMsg))
	if error != nil {
		fmt.Println("conn.write error...")
		return false
	}
	return true
}

//公聊
func (c *Client) PublicChat() {
	var chatMsg string
	fmt.Println(">>>>请输入聊天内容，输入exit退出")
	fmt.Scanln(&chatMsg)

	for chatMsg != "exit" {
		if len(chatMsg) != 0 {
			msg := chatMsg + "\n"
			_, error := c.conn.Write([]byte(msg))
			if error != nil {
				fmt.Println("conn.Write error....")
				break
			}
		}

		chatMsg = ""
		fmt.Println(">>>>请输入聊天内容，输入exit退出")
		fmt.Scanln(&chatMsg)
	}
}

//私聊
func (c *Client) PrivateChat() {
	var remoteUser string
	var chatMsg string

	c.SelectUsers()

	fmt.Println(">>>>请输入聊天对象的用户名，输入exit退出")
	fmt.Scanln(&remoteUser)
	for remoteUser != "exit" {

		fmt.Println(">>>>请输入聊天内容，输入exit退出")
		fmt.Scanln(&chatMsg)

		for chatMsg != "exit" {
			if len(chatMsg) != 0 {
				msg := "to|" + remoteUser + "|" + chatMsg + "\n\n"
				_, error := c.conn.Write([]byte(msg))
				if error != nil {
					fmt.Println("conn.Write error....")
					break
				}
			}

			chatMsg = ""
			fmt.Println(">>>>请输入聊天内容，输入exit退出")
			fmt.Scanln(&chatMsg)
		}

		c.SelectUsers()
		remoteUser = ""
		fmt.Println(">>>>请输入聊天对象的用户名，输入exit退出")
		fmt.Scanln(&remoteUser)
	}

}

//查询在线用户
func (c *Client) SelectUsers() {
	sendMsg := "who\n"
	_, error := c.conn.Write([]byte(sendMsg))
	if error != nil {
		fmt.Println("conn.Write error....")
		return
	}
}

//处理server返回的消息
func (c *Client) DealResponse() {
	io.Copy(os.Stdout, c.conn)
}
func (c *Client) Run() {
	for c.flag != 0 {
		for c.menu() != true {

		}
		switch c.flag {
		case 1:
			//公聊
			c.PublicChat()
		case 2:
			//私聊
			c.PrivateChat()
		case 3:
			//修改用户名
			c.UpdateName()
		}
	}
}

var serverIp string
var serverPort int

func init() {
	flag.StringVar(&serverIp, "ip", "127.0.0.1", "设置服务器IP地址（默认为127.0.0.1）")
	flag.IntVar(&serverPort, "port", 8888, "设置服务器端口（默认为8888）")
}
func main() {
	flag.Parse()
	client := NewClient(serverIp, serverPort)
	if client == nil {
		fmt.Println(">>>>链接服务器失败")
		return
	}

	go client.DealResponse()

	fmt.Println(">>>>链接服务器成功")
	client.Run()
}
